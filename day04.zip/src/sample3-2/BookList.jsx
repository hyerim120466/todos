import React from "react";
import BookItem from "./BookItem";

const BookList = ({ data, onShow, onDel }) => {
  return (
    <ul className="list">
      {data.map((item) => (
        <BookItem key={item.id} {...item} onShow={onShow} onDel={onDel} />
      ))}
    </ul>
  );
};

export default BookList;
