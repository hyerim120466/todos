import React from "react";

const BookItem = ({ id, title, author, isDone, onShow, onDel }) => {
  return (
    <li style={{ backgroundColor: isDone ? "skyBlue" : "" }}>
      <div onClick={() => onShow(id)}>
        <h3>제목 : {title}</h3>
        <p>저자 : {author}</p>
      </div>
      <button onClick={() => onDel(id)}>삭제</button>
    </li>
  );
};

export default BookItem;
