import BookList from "./BookList";
import BookDisplay from "./BookDisplay";
import { useState } from "react";
import dataList from "../assets/api/bookListData1";

import "./style.scss";

const Books = () => {
  const [data, setData] = useState(dataList);
  const [current, setCurrent] = useState("타이틀 출력");
  const [isView, setIsView] = useState(false);
  const onShow = (id) => {
    // current
    // data => isDone - true/false
    setData(
      data.map((item) =>
        item.id === id ? { ...item, isDone: true } : { ...item, isDone: false }
      )
    );
    setCurrent(data.find((item) => item.id === id).title);
    // display 숨기기 상태에서 li를 누르면 display 나타나기
    if (!isView) {
      setIsView(true);
    }
  };

  // 전체삭제
  const onReset = () => {
    setData([]);
  };
  // 복구
  const onRestore = () => {
    setData(dataList);
  };
  // 목록삭제
  const onDel = (id) => {
    setData(data.filter((item) => item.id !== id));
  };
  // 보이기 ,숨기기
  const onView = () => {
    setIsView(!isView);
  };
  return (
    <div className="book-list">
      <h2>BOOK LIST</h2>
      <p className="btn">
        <button onClick={onReset}>전체삭제</button>
        <button onClick={onRestore}>복구</button>
        <button onClick={onView}>{isView ? "숨기기" : "보이기"}</button>
      </p>
      <BookList data={data} onShow={onShow} onDel={onDel} />
      {isView && <BookDisplay current={current} />}
    </div>
  );
};

export default Books;
