// import Test8 from "./components/Test8";

import Todos from "./sample4_1/Todos/Todos";

// import Gallery from "./sample1/Gallery";

// import Books from "./sample3/Books";
// import Books from "./sample3-2/Books";

// import Movie from "./sample2/Movie";

const App = () => {
  return (
    <div>
      {/* <Gallery /> */}
      {/* <Movie /> */}
      {/* <Books /> */}
      <Todos />
    </div>
  );
};

export default App;
