import { useRef, useState } from 'react';
import Test6Sub from './Test6Sub';

const dataList = [
    { id: 1, name: '홍길동' },
    { id: 2, name: '박연진' },
    { id: 3, name: '송혜교' },
    { id: 4, name: '김고은' },
    { id: 5, name: '김태리' },
];

const Test6 = () => {
    const [data, setData] = useState(dataList);
    // const no = useRef(dataList.length + 1);
    const no = useRef(data.length + 1);
    //값이 있는곳에서 함수를 처리 70%정도 (반드시는 아니다 )
    const onAdd = (name) => {
        setData([
            ...data,
            {
                id: no.current++,
                name,
            },
        ]);
    };
    const onDel = (id) => {
        setData(data.filter((item) => item.id !== id));
    };
    const onEdit = (id) => {
        setData(data.map((item) => (item.id === id ? { ...item, name: '전종서' } : item)));
    };

    return (
        <div>
            <Test6Sub onAdd={onAdd} onDel={onDel} onEdit={onEdit} />
            <hr />
            <ul>
                {data.map((item) => (
                    <li key={item.id}>
                        {item.id} / {item.name}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Test6;
