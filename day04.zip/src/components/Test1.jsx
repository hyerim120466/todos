//src안에 어디든/assets 이미지는 import 가져온다 (10%)
// public 안에 이미지는 html 처럼 사용가능 (많이 사용)
import img1 from '../assets/images/bimg0.jpg';
import img2 from '../assets/images/bimg1.jpg';
import img3 from '../assets/images/bimg2.jpg';
const Test1 = () => {
    return (
        <div>
            <h2>이미지 처리</h2>
            <img src={img1} alt='' />
            <img src={img2} alt='' />
            <img src={img3} alt='' />
            <hr />
            {/* 최상위 public*/}
            <img src='images/bimg0.jpg' alt='' />
            <img src='./images/bimg0.jpg' alt='' />
        </div>
    );
};

export default Test1;
