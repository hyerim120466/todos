import { useRef } from 'react';

const Test3 = () => {
    const refScroll = useRef(null);
    const onTest1 = () => {
        refScroll.current.scrollTop = 0;
    };
    const onTest2 = () => {
        refScroll.current.scrollTop = refScroll.current.scrollHeight;
    };

    return (
        <>
            <p>
                <button onClick={onTest1}>처음</button>
                <button onClick={onTest2}>마지막</button>
            </p>
            <div
                ref={refScroll}
                style={{
                    margin: 30,
                    padding: 15,
                    border: '1px solid #000',
                    width: 300,
                    height: 300,
                    overflowY: 'scroll',
                }}
            >
                <p>처음 시작</p>
                <p>안녕하세요</p>
                <p>안녕하세요</p>
                <p>안녕하세요</p>
                <p>안녕하세요</p>
                <p>안녕하세요</p>
                <p>안녕하세요</p>
                <p>안녕하세요</p>
                <p>안녕하세요</p>
                <p>안녕하세요</p>
                <p>안녕하세요</p>
                <p>안녕하세요</p>
                <p>안녕하세요</p>
                <p>안녕하세요</p>
                <p>안녕하세요</p>
                <p>안녕하세요</p>
                <p>안녕하세요</p>
                <p>안녕하세요</p>
                <p>마지막 끝</p>
            </div>
        </>
    );
};

export default Test3;
