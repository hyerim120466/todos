import { useRef, useState } from "react";

// TodoList 원리
const TodoItem = ({ id, text, onDel }) => {
  return (
    <li>
      {id} / {text}
      <button onClick={() => onDel(id)}>삭제</button>
    </li>
  );
};
const TodoList = ({ data, onDel }) => {
  return (
    <ul>
      {data.map((item) => (
        <TodoItem key={item.id} {...item} onDel={onDel} />
      ))}
    </ul>
  );
};
const TodoInput = ({ onAdd }) => {
  const [text, setText] = useState("");
  const textRef = useRef("");
  const changeInput = (e) => {
    setText(e.target.value);
  };
  const onSub = (e) => {
    e.preventDefault();
    onAdd(text);
    setText("");
    textRef.current.focus();
  };
  return (
    <form onSubmit={onSub}>
      <input type="text" ref={textRef} value={text} onChange={changeInput} />
      <button type="submit">추가</button>
    </form>
  );
};

const Test8 = () => {
  const [data, setData] = useState([
    { id: 1, text: "운동하기" },
    { id: 2, text: "점심먹기" },
    { id: 3, text: "친구만나기" },
    { id: 4, text: "공부하기" },
  ]);
  //   고유번호
  const no = useRef(data.length + 1);

  // 추가
  const onAdd = (text) => {
    setData([
      ...data,
      {
        id: no.current++,
        text,
      },
    ]);
  };
  // 삭제
  const onDel = (id) => {
    setData(data.filter((item) => item.id !== id));
  };
  return (
    <div>
      <h2>할일 만들기</h2>
      <TodoInput onAdd={onAdd} />
      <TodoList data={data} onDel={onDel} />
    </div>
  );
};

export default Test8;
