import { useRef, useState } from 'react';
import Test7Sub from './Test7Sub';

const Test7 = () => {
    const names =
        '김고은,전종서,김태리,김고은,이도현,이수근,강호동,유재석,하하,이나은,임수정'.split(',');

    const [count, setCount] = useState(100);
    const [data, setData] = useState([{ id: 1, name: '홍길동' }]);
    const no = useRef(2);
    const css1 = { fontSize: 40 };

    const onTest1 = (x) => {
        setCount(count + x);
    };
    const onTest2 = () => {
        const ran = Math.floor(Math.random() * names.length);
        setData([
            ...data,
            {
                id: no.current++,
                name: names[ran],
            },
        ]);
    };

    return (
        <div>
            <Test7Sub onTest1={onTest1} onTest2={onTest2} />
            <hr />
            <h2 style={css1}>숫자 : {count} </h2>
            <hr />
            <ul style={css1}>
                {data.map((item) => (
                    <li key={item.id}>
                        {item.id} / {item.name}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Test7;
