import { useRef, useState } from "react";

const TodoItem = ({ id, text, onDel }) => {
  return (
    <li>
      {id} / {text}
      <button onClick={() => onDel(id)}>삭제</button>
    </li>
  );
};
const TodoInput = ({ onAdd }) => {
  const [text, setText] = useState("");
  const changeInput = (e) => {
    setText(e.target.value);
  };
  const onSub = (text) => {
    onAdd(text);
  };
  return (
    <form onSubmit={onSub}>
      <input type="text" name="" id="" value={text} changeInput={changeInput} />
      <button type="submit">삭제</button>
    </form>
  );
};
const TodoList = ({ data, onDel }) => {
  return (
    <ul>
      {data.map((item) => (
        <TodoItem key={item.id} {...item} onDel={onDel} />
      ))}
    </ul>
  );
};
const Test8Prac = () => {
  const [data, setData] = useState([
    { id: 1, text: "운동하기" },
    { id: 2, text: "점심먹기" },
    { id: 3, text: "친구만나기" },
    { id: 4, text: "공부하기" },
  ]);
  const no = useRef(data.length + 1);
  const onDel = (id) => {
    setData(data.filter((item) => item.id !== id));
  };
  const onAdd = () => {};
  return (
    <div>
      <div>
        <h2>할일 만들기</h2>
        <TodoInput onAdd={onAdd} />
        <TodoList data={data} onDel={onDel} />
      </div>
    </div>
  );
};

export default Test8Prac;
