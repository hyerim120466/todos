import { useRef, useState } from 'react';

const dataList = [
    { id: 1, name: '홍길동' },
    { id: 2, name: '박연진' },
    { id: 3, name: '송혜교' },
    { id: 4, name: '김고은' },
    { id: 5, name: '김태리' },
];
const Test5 = () => {
    const [data, setData] = useState(dataList);
    const no = useRef(1);

    const onAdd1 = () => {
        setData([
            ...data,
            {
                id: no.current++,
                name: '전지현',
            },
        ]);
    };
    const onAdd2 = (name) => {
        setData([
            ...data,
            {
                id: no.current++,
                name,
            },
        ]);
    };

    // 삭제
    const onDel1 = () => {
        const newData = data.filter((item) => item.name !== '전지현');
        setData(newData);
    };

    //삭제 중요
    const onDel2 = (id) => {
        setData(data.filter((item) => item.id !== id));
    };

    const onMod1 = () => {
        const newData = data.map((item) => {
            if (item.name === '홍길동') {
                return {
                    ...item,
                    name: '조용필',
                };
            } else {
                return item;
            }
        });
        setData(newData);
    };

    const onMod2 = (num) => {
        setData(data.map((item) => (item.id === num ? { ...item, name: '김철수' } : item)));
    };
    const onMod3 = (id) => {
        setData(
            data.map((item) =>
                item.id === id ? { ...item, name: '아무개' } : { ...item, name: '나머지변경' }
            )
        );
    };

    return (
        <div>
            <h2>데이터 추가/ 삭제/수정 - js </h2>
            <p>
                <h3>추가</h3>
                <button onClick={onAdd1}> 전지현 </button>
                <button onClick={() => onAdd2('강호동')}> 강호동 </button>
                <button onClick={() => onAdd2('유재석')}> 유재석 </button>
            </p>
            <p>
                <h3>삭제</h3>
                <button onClick={onDel1}> 홍길동 </button>
                <button onClick={() => onDel2(3)}> 송혜교 </button>
                <button onClick={() => onDel2(4)}> 김태리 </button>
            </p>
            <p>
                <h3>수정</h3>
                <button onClick={onMod1}> 홍길동 </button>
                <button onClick={() => onMod2(3)}> 송혜교 </button>
                <button onClick={() => onMod3(4)}> 김고은 </button>
            </p>

            <hr />
            <ul>
                {data.map((item) => (
                    <li key={item.id}>
                        {item.id} / {item.name}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Test5;
