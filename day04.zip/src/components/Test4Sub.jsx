const Test4Sub = ({ username, age }) => {
    return (
        <div>
            <h2>
                이름은 {username} 이고 나이는 {age} 입니다
            </h2>
        </div>
    );
};

export default Test4Sub;
