import { useRef, useState } from 'react';
import Test4Sub from './Test4Sub';

const Test4 = () => {
    const nameRef = useRef(null);
    const [user, setUser] = useState({
        username: '',
        age: '',
    });
    // user.usernmame , user.age
    //구조분해
    const { username, age } = user;

    const now = new Date();
    const y = now.getFullYear();

    const changeInput = (e) => {
        const { name, value } = e.target;
        setUser({
            ...user,
            [name]: value,
        });
    };
    const onReset = () => {
        setUser({
            username: '',
            age: '',
        });
        nameRef.current.focus();
    };

    return (
        <div>
            <h2>{y}년 : </h2>
            <h2>월/일 :</h2>
            <h2>시간 :</h2>

            <input
                ref={nameRef}
                type='text'
                value={username}
                name='username'
                onChange={changeInput}
            />
            <input type='text' name='age' value={age} onChange={changeInput} />
            <button onClick={onReset}>초기화</button>
            <hr />
            <Test4Sub username={username} age={age} />
        </div>
    );
};

export default Test4;
