const Test6Sub = ({ onAdd, onDel, onEdit }) => {
    return (
        <div>
            <p>
                <h2>추가</h2>
                <button onClick={() => onAdd('유재석')}>유재석</button>
                <button onClick={() => onAdd('강호동')}>강호동</button>
            </p>
            <p>
                <h2>삭제</h2>
                <button onClick={() => onDel(3)}> 송혜교 </button>
                <button onClick={() => onDel(4)}>김고은</button>
            </p>
            <p>
                <h2>수정</h2>
                <button onClick={() => onEdit(4)}>김고은-전종서로</button>
            </p>
        </div>
    );
};

export default Test6Sub;
