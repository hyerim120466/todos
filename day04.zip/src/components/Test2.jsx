import { useRef, useState } from 'react';

const Test2 = () => {
    const ref1 = useRef(null);
    const ref2 = useRef();
    const [count, setCount] = useState(0); // 상태값
    const refCnt = useRef(0); // 값유지( 렌더링 방지 )

    const onTest1 = () => {
        ref1.current.style.color = 'tomato';
        ref1.current.style.fontSize = '20px';
        ref1.current.style.backgroundColor = 'yellow';
        ref1.current.style.padding = '5px 10px';
        ref1.current.style.border = '1px solid #000';
        ref1.current.style.margin = '15px';
    };
    const onTest2 = () => {
        ref2.current.focus();
    };
    const onTest3 = () => {
        setCount(count + 1);
        refCnt.current++; // 렌더링 발생하지 않는다
        // refCnt.current += 1
    };
    return (
        <div>
            <h2>useRef</h2>
            <h3>상태값 변경 : {count}</h3>
            <h3>ref값 변경(주로고유값) :{refCnt.current} </h3>

            <input type='text' name='' id='' ref={ref2} />
            <p ref={ref1}>
                값이 변경되지 않고 유지 직접 DOM 요소에 접근할때 ref 객체를 이용해서 자식요소에 접근
                useRef ( DOM 요소에 접근, 값유지 ) .current
            </p>
            <p>
                <button onClick={onTest1}>확인</button>
                <button onClick={onTest2}>확인</button>
                <button onClick={onTest3}>값 변경</button>
            </p>
        </div>
    );
};

export default Test2;

/*
 형식1)
  const inputEl = useRef(null);
  const inputEl = useRef();
  <input ref={inputEl} type="text" />
  inputEl.current.xxx = 값 
  inputEl.current.focus();

  useState : 값을 변경할때( 유동처리 )
  useRef : 한번만 처리 유지 - input 값을 담아서 넘길때 ( 좋은건 아니다 )

  useRef는 .current 프로퍼티로 전달된 인자(initialValue)로 초기화된 변경 가능한 ref 객체를 반환합니다. 반환된 객체는 컴포넌트의 전 생애주기를 통해 유지될 것입니다.

 ///////////////////////////////

  const inputEl = useRef(숫자);
  inputEl.current++  : 고유값 처리할때 

  //////////////////////
  Ref를 사용해야 할 때
  Ref의 바람직한 사용 사례는 다음과 같습니다.

    포커스, 텍스트 선택영역, 
    혹은 미디어의 재생을 관리할 때.
    애니메이션을 직접적으로 실행시킬 때.
    서드 파티 DOM 라이브러리를 React와 같이 사용할 때.
    선언적으로 해결될 수 있는 문제에서는 ref 사용을 지양하세요.




*/
