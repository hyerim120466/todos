const Test7Sub = ({ onTest1, onTest2 }) => {
    return (
        <div>
            <div>
                <h2>숫자 계산</h2>
                <p>
                    <button onClick={() => onTest1(10)}>10</button>
                    <button onClick={() => onTest1(-10)}>-10</button>
                    <button onClick={() => onTest1(30)}>30</button>
                    <button onClick={() => onTest1(-50)}>-50</button>
                </p>
                <h2>
                    <button onClick={onTest2}>랜덤으로 출력</button>
                </h2>
            </div>
        </div>
    );
};

export default Test7Sub;
