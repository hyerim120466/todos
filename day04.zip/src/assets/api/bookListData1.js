export default [
  { id: 1, title: "언젠가 우리가 같은 별을", author: "차인표", isDone: false },
  { id: 2, title: "빛이 이끄는 곳으로", author: "백희성", isDone: false },
  { id: 3, title: "영원한 천국", author: "정유미", isDone: false },
  { id: 4, title: "불변의 법칙", author: "모건 하우절", isDone: false },
  { id: 5, title: "모순", author: "양귀자 ", isDone: false },
];
