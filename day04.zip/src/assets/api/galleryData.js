const list = [
  { id: 1, imgurl: "../images/img0.jpg", title: "우와와인", isDone: true },
  { id: 2, imgurl: "../images/img1.jpg", title: "티인감", isDone: false },
  { id: 3, imgurl: "../images/img2.jpg", title: "침대..??", isDone: false },
  {
    id: 4,
    imgurl: "../images/img3.jpg",
    title: "크리스마스분위기",
    isDone: false,
  },
  {
    id: 5,
    imgurl: "../images/img4.jpg",
    title: "폭신폭신 베개",
    isDone: false,
  },
];

export default list;
