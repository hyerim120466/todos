import "./style.scss";
import GalleryBig from "./GalleryBig";
import GalleryList from "./GalleryList";
import dataList from "../assets/api/galleryData";
import { useState } from "react";

const Gallery = () => {
  const [data, setData] = useState(dataList);
  const [current, setCurrent] = useState(data[0]); //하나의 데이터 처리 첫번째 {} 처리
  const onView = (id) => {
    // setCurrent(data[id - 1]); // 단순 출력 시는 가능
    // find , findIndex
    setCurrent(data.find((item) => item.id === id));
    // 수정 => isDone => true/false
    setData(
      data.map((item) =>
        item.id === id ? { ...item, isDone: true } : { ...item, isDone: false }
      )
    );
  };
  return (
    <div className="wrap">
      <GalleryBig {...current} />
      {/* <GalleryBig current={current} /> */}
      <GalleryList data={data} onView={onView} />
      <p style={{ fontSize: 20, margin: 10 }}>
        {current.id} / {data.length}
      </p>
    </div>
  );
};

export default Gallery;
