const GalleryItem = ({ id, imgurl, title, isDone, onView }) => {
  // const GalleryItem = ({item }) => {
  //   const { id, name, title, imgurl, isDone } = item;
  return (
    <li className={isDone ? "on" : ""} onClick={() => onView(id)}>
      <img src={imgurl} alt="" />
    </li>
  );
};

export default GalleryItem;
