const GalleryBig = ({ imgurl, title }) => {
  // const GalleryBig = ({ current }) => {
  // const { id, name, imgurl, title, isDone } = current;
  return (
    <div className="bigimg">
      <h2>{title}</h2>
      <img src={imgurl} alt={title} />
    </div>
  );
};

export default GalleryBig;
