import BookList from "./BookList";
import BookDisplay from "./BookDisplay";
import { useState } from "react";
import dataList from "../assets/api/bookListData";

import "./style.scss";

const Books = () => {
  const [data, setData] = useState(dataList);
  const [current, setCurrent] = useState("타이틀 출력");
  const change = (title) => {
    setCurrent();
  };
  return (
    <div className="book-list">
      <h2>BOOK LIST</h2>
      <BookList data={data} current={current} setCurrent={setCurrent} />
      <BookDisplay current={current} />
    </div>
  );
};

export default Books;
