import React from "react";

const BookItem = ({ title, author, current, setCurrent, isDone }) => {
  const onShow = () => {
    setCurrent(current);
  };
  return (
    <li onClick={onShow} style={{ backgroundColor: isDone ? "skyBlue" : "" }}>
      <h3>제목 : {title}</h3>
      <p>저자 : {author}</p>
    </li>
  );
};

export default BookItem;
