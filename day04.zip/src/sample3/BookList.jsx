                  import React from "react";
import BookItem from "./BookItem";

const BookList = ({ data, current, setCurrent }) => {
  return (
    <ul className="list">
      {data.map((item) => (
        <BookItem
          key={item.id}
          {...item}
          isDone={current === item.title}
          current={item.title}
          setCurrent={setCurrent}
        />
      ))}
    </ul>
  );
};

export default BookList;
