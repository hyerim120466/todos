const MovieItem = ({ id, imgurl, title, date, actor, director, onDel }) => {
  return (
    <article>
      <div className="left">
        <img src={imgurl} alt="" />
      </div>
      <div className="right">
        <h3>{title}</h3>
        <ul>
          <li>출연진 : {actor} </li>
          <li>감독 : {director}</li>
          <li>개봉일 : {date}</li>
        </ul>
        <button onClick={() => onDel(id)}>제거</button>
      </div>
    </article>
  );
};

export default MovieItem;
