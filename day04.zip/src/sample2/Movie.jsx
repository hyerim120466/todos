import "./style.scss";
import MovieItem from "./MovieItem";
import dataList from "../assets/api/posterData";
import { useState } from "react";

const Movie = () => {
  const [data, setData] = useState(dataList);
  const onDel = (id) => {
    setData(data.filter((item) => item.id !== id));
  };

  return (
    <div className="wrap">
      {/* map */}
      {data.map((item) => (
        <MovieItem key={item.id} {...item} onDel={onDel} />
      ))}
    </div>
  );
};

export default Movie;
