import { useState } from "react";
import TodoInput from "../TodoInput/TodoInput";
import TodoList from "../TodoList/TodoList";
import "./Todos.scss";

const Todos = () => {
  const [todos, setTodos] = useState("출력");
  return (
    <div className="Todos">
      <h2>할 일 만들기</h2>
      <TodoInput />
      <TodoList todos={todos} />
    </div>
  );
};

export default Todos;

/* 
    1. css 처리는 html/css 처럼 전체 스타일 style.scss 만들고
       연결해서 사용가능 ( 모든 css style.css 관리) : 나쁜 예

    2. 보통은 
       컴포넌트 하나에 css(scss) 하나씩 연결 처리
       
    3. 이후 설명....   
*/
