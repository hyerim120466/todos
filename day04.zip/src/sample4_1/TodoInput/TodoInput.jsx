import "./TodoInput.scss";

const TodoInput = () => {
  return (
    <form className="TodoInput">
      <input type="text" />
      <button>추가</button>
    </form>
  );
};

export default TodoInput;
