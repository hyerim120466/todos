import React from "react";

const TodoItem = () => {
  return (
    <li>
      <div>
        <span>✓</span>
        <em>텍스트</em>
      </div>

      <button>삭제</button>
    </li>
  );
};

export default TodoItem;
