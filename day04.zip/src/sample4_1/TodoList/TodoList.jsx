import TodoItem from "./TodoItem";
import "./TodoList.scss";

const TodoList = ({ todos }) => {
  return (
    <ul className="TodoList">
      {todos.map((todo) => (
        <TodoItem />
      ))}
    </ul>
  );
};

export default TodoList;
