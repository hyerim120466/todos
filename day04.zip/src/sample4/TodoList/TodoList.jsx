import TodoItem from "./TodoItem";
import "./TodoList.scss";

const TodoList = ({ todos, onDel, onEdit }) => {
    
  return (
    <div className="TodoList">
      {todos.map((todo) => (
        <TodoItem key={todo.id} {...todo} onDel={onDel} onEdit={onEdit} />
      ))}
    </div>
  );
};

export default TodoList;
