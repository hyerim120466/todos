import React from "react";

const TodoItem = ({ id, text, isDone, onEdit, onDel }) => {
  return (
    <li className={isDone ? "on" : ""}>
      <div>
        <span onClick={() => onEdit(id)}>✓</span>
        <em>{text}</em>
      </div>
      <button onClick={() => onDel(id)}>삭제</button>
    </li>
  );
};

export default TodoItem;
