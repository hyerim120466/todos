import React from "react";
import BookItem from "./BookItem";

const BookList = ({ data, onShow }) => {
  return (
    <ul className="list">
      {data.map((item) => (
        <BookItem key={item.id} {...item} onShow={onShow} />
      ))}
    </ul>
  );
};

export default BookList;
