import React from "react";

const BookDisplay = ({ current }) => {
  return (
    <div className="display">
      <h2 >{current}</h2>
    </div>
  );
};

export default BookDisplay;
