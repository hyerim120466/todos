import "./style.scss";
import BookList from "./BookList";
import BookDisplay from "./BookDisplay";
import { useState } from "react";
import dataList from "../assets/api/bookListData1";

const Books = () => {
  const [data, setData] = useState(dataList);
  const [current, setCurrent] = useState("도서 제목 출력");
  // 변경시키는 함수 state가 있는곳에서 처리하자 (80%)
  const onShow = (id) => {
    // current
    // data => isDone - true/false
    setData(
      data.map((item) =>
        item.id === id ? { ...item, isDone: true } : { ...item, isDone: false }
      )
    );
    setCurrent(data.find((item) => item.id === id).title);
  };
  return (
    <div className="book-list">
      <h2>BOOK LIST</h2>
      <BookList data={data} onShow={onShow} />
      <BookDisplay current={current} />
    </div>
  );
};

export default Books;
