import React from "react";

const BookItem = ({ id, title, author, isDone, onShow }) => {
  return (
    <li
      onClick={() => onShow(id)}
      style={{ backgroundColor: isDone ? "skyBlue" : "" }}
    >
      <h3>제목 : {title}</h3>
      <p>저자 : {author} </p>
    </li>
  );
};

export default BookItem;
